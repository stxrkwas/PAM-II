# Aula 01 - Lista de Exercicios
Lista de exercícios de revisão de PAM 1.
