package fundamentos

//Utlizando If/Else

fun main(args: Array<String>){

    val nota: Double = 6.9

    if(nota >= 7.0){
        println("Aprovado!!")
    }

    else{
        println("Reprovado!")
    }
}