package fundamentos

//While

fun main(args: Array<String>){

    var contador: Int = 1

    while(contador <= 10){

        println(contador)
        contador++

    }
}
