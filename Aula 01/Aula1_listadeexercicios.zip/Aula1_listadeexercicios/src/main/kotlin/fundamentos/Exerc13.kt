package fundamentos

//Refatorando para When

fun main(args: Array<String>){

    val nota = 4

    when(nota){

        10, 9 -> print("Fantástico")
        8, 7 -> print("Parabéns")
        6, 5, 4 -> print("Tem como recuperar")
        in 3..0 -> print("Nota inválida")
        else -> print("Nota inválida")

    }
}