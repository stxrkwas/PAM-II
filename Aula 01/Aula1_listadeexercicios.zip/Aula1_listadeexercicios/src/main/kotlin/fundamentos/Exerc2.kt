package fundamentos

//Função
fun main() {

    val name = "Kotlin"

    println("Hello, " + name + "!")

    for(i in 1..5){

        println("i = $i")
    }
}